#include <stdio.h>

struct rectangle
{
    float length;
    float breadth;
};

int main()
{
    struct rectangle r[5];
    return 0;
}