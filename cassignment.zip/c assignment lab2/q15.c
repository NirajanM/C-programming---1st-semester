#include<stdio.h>

int main(){
    int n;
    printf("***asssignment by Nirajan Malla***\n");
    printf("enter the number : ");
    scanf("%d",&n);
    if(n>=0)
    {
        printf("given number is positive");
    }
    else
    {
        printf("given number is negative");
    }
    return 0;
}