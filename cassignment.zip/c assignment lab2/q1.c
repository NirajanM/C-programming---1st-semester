#include<stdio.h>

int main(){
    int n;
    printf("***asssignment by Nirajan Malla***\n");
    printf("enter the number : ");
    scanf("%d",&n);
    if(n%2==0)
    {
        printf("the number entered is even\n");
    }
    else
    {
        printf("the number entered is odd\n");
    }
    return 0;
}