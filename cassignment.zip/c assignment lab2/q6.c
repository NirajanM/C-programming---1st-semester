#include<stdio.h>

int main(){
    float n1,n2;
    printf("***asssignment by Nirajan Malla***\n");
    printf("enter two numbers : ");
    scanf("%f%f",&n1,&n2);
    if(n1==n2)
    {
        printf("both number are equal");
    }
    else
    {
        printf("numbers are different");
    }
    return 0;
}