#include<stdio.h>

int main(){
    float l,b,area;
    printf("***assignment by Nirajan Malla***\n");
    printf("enter the length and breadth:\n");
    scanf("%f%f",&l,&b);
    area=0.5*l*b;
    printf("the area of triangle is %.2f",area);
    return 0;
}