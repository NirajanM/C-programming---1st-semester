#include<stdio.h>

int main(){
    int i=7247;
    int j=i%10;
    printf("%d",j);
    return 0;
}