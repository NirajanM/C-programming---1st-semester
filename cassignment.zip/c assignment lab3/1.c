#include<stdio.h>

void display(int a)
{
    for(int i=1;i<=a;i++)
    {
        printf("%d ",i);
    }
}

int main(){
    printf("***assignment by Nirajan Malla***\n");
    display(100);

    return 0;
}