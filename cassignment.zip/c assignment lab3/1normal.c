#include<stdio.h>

int main(){
    printf("***assignment by Nirajan Malla***\n");
    for(int i=1;i<=100;i++)
    {
        printf("%d ",i);
    }

    return 0;
}