#include<stdio.h>

int main(){
    printf("***assignment by Nirajan Malla***\n");
    for(int i=0;i<=100;i++)
    {
        if(i%2==0)
        {
            printf("%d ",i);
        }
    }

    return 0;
}