#include<stdio.h>

int main(){
    int n;
    printf("***asssignment by Nirajan Malla***\n");
    printf("enter the number : ");
    scanf("%d",&n);
    if(n>=100)
    {
        printf("given number is greater than or equal to 100");
    }
    else
    {
        printf("given number is less than 100");
    }
    return 0;
}