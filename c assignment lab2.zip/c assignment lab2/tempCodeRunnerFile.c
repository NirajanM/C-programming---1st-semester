 printf("***asssignment by Nirajan Malla***\n");
    printf("enter the number : ");
    scanf("%d",&n);